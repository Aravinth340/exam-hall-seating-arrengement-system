<?php
   session_start();
   $DateSe=$DateTe=$DateBe=array();

   $classVector = array_splice($_SESSION,4);

   $seTimeTable = $_SESSION['SE'];
   $slot = explode("  ",trim(array_shift($seTimeTable)));
   foreach ($slot as $s)
   {
       $dateD =array_shift($seTimeTable);
       for($i = 1;$i<=$s;$i++)
       {
           $DateSe[$dateD][] = array_shift($seTimeTable);
       }
   }

   $teTimeTable = $_SESSION['TE'];
   $slot = explode("  ",trim(array_shift($teTimeTable)));
   foreach ($slot as $s)
   {
       $dateD =array_shift($teTimeTable);
       for($i = 1;$i<=$s;$i++)
       {
           $DateTe[$dateD][] = array_shift($teTimeTable);
       }
   }

   $beTimeTable = $_SESSION['BE'];
   $slot = explode("  ",trim(array_shift($beTimeTable)));
   foreach ($slot as $s)
   {
       $dateD =array_shift($beTimeTable);
       for($i = 1;$i<=$s;$i++)
       {
           $DateBe[$dateD][] = array_shift($beTimeTable);
       }
   }

   error_reporting( E_ERROR | E_PARSE | E_CORE_ERROR | E_CORE_WARNING | E_COMPILE_ERROR | E_COMPILE_WARNING );

   $tt;

   $tt[0][0][0]=$_POST["SUB21"];
   $tt[0][0][1]=$_POST["SUB22"];
   $tt[0][1][0]=$_POST["SUB23"];
   $tt[0][1][1]=$_POST["SUB24"];
   $tt[0][2][0]=$_POST["SUB25"];
   $tt[0][2][1]=$_POST["SUB26"];

   $tt[1][0][0]=$_POST["SUB31"];
   $tt[1][0][1]=$_POST["SUB32"];
   $tt[1][1][0]=$_POST["SUB33"];
   $tt[1][1][1]=$_POST["SUB34"];
   $tt[1][2][0]=$_POST["SUB35"];
   $tt[1][2][1]=0;

   $tt[2][0][0]=$_POST["SUB41"];
   $tt[2][0][1]=$_POST["SUB42"];
   $tt[2][1][0]=$_POST["SUB43"];
   $tt[2][1][1]=$_POST["SUB44"];
   $tt[2][2][0]=0;
   $tt[2][2][1]=0;

   class teacher
   {
       public $name;
       public $sub;
   };

   $n;
   $v;
   $te = array();
   // FIX: Initialize all teacher objects before use
   for($i=0;$i<10;$i++) {
       $te[$i] = new teacher();
   }

   $yearinclass;

   $yearinclass[0][0]=$_POST["class11"];
   $yearinclass[0][1]=$_POST["class12"];
   $yearinclass[1][0]=$_POST["class21"];
   $yearinclass[1][1]=$_POST["class22"];
   $yearinclass[2][0]=$_POST["class31"];
   $yearinclass[2][1]=$_POST["class32"];

   $total=30;

   $lectures = array();
   $k=0;$j=0;
   for($i=0;$i<10;$i++)
   {
       if($i==0)
       {
           $te[$i]->name="Prof. Dr. Syed Akhter Hossain";
           $te[$i]->sub[0]="43";
           $te[$i]->sub[1]="31";
       }
       if($i==1)
       {
           $te[$i]->name="Dr. Sheak Rashed Haider Noori";
           $te[$i]->sub[0]="26";
           $te[$i]->sub[1]="33";
       }
       if($i==2)
       {
           $te[$i]->name="Dr. Md. Mustafizur Rahman";
           $te[$i]->sub[0]="22";
           $te[$i]->sub[1]="34";
       }
       if($i==3)
       {
           $te[$i]->name="Dr. S. M. Aminul Haque";
           $te[$i]->sub[0]="41";
           $te[$i]->sub[1]="0";
       }
       if($i==4)
       {
           $te[$i]->name="Professor Dr. Md. Ismail Jabiullah";
           $te[$i]->sub[0]="25";
           $te[$i]->sub[1]="0";
       }
       if($i==5)
       {
           $te[$i]->name="Dr. S.R.Subramanya";
           $te[$i]->sub[0]="35";
           $te[$i]->sub[1]="0";
       }
       if($i==6)
       {
           $te[$i]->name="Dr. Neil Perez Balba";
           $te[$i]->sub[0]="42";
           $te[$i]->sub[1]="32";
       }
       if($i==7)
       {
           $te[$i]->name= "Dr. Bibhuti Roy";
           $te[$i]->sub[0]="24";
           $te[$i]->sub[1]= "44" ;
       }
       if($i==8)
       {
           $te[$i]->name="Mr. Anisur Rahman";
           $te[$i]->sub[0]="31";
           $te[$i]->sub[1]="0";
       }
       if($i==9)
       {
           $te[$i]->name="Mr. Gazi Zahirul Islam";
           $te[$i]->sub[0]="21";
           $te[$i]->sub[1]="0";
       }

       if($te[$i]->sub[0]==0 || $te[$i]->sub[1]==0)
       {
           $lectures[$i]=5;
           $total=$total-5;
           $k++;
       }
       else
       {
           if($j<4)
           {
               $lectures[$i]=2;
               $total=$total-2;
               $j++;
           }
           else
           {
               $lectures[$i]=1;
               $total=$total-1;
               $j++;
           }
       }
   }

   for($i=0;$i<3;$i++)
   {
       for($j=0;$j<3;$j++)
       {
           for($k=0;$k<2;$k++)
           {
               for($m=0;$m<2;$m++)
               {
                   $l=$yearinclass[$j][$m];
                   $l=$l-2;
                   $x=$tt[$l][$i][$k];
                   $subjectinclass[$i][$j][$k][$m]=$x;
               }
           }
       }
   }

   $teacherinclass;
   $total=30;
   $l=0;
   $year;

   for($i=0;$i<3;$i++)
   {
       for($j=0;$j<3;$j++)
       {
           for($k=0;$k<2;$k++)
           {
               for($m=0;$m<2;$m++)
               {
                   $flag=0;
                   do
                   {
                       if($l==10)
                       {
                           $l=0;
                       }
                       else if($subjectinclass[$i][$j][$k][$m] ==0)
                       {
                           $teacherinclass[$i][$j][$k][$m]=100;
                           $flag=1;
                       }
                       else if($lectures[$l]==0)
                       {
                           $l++;
                       }
                       else if($subjectinclass[$i][$j][$k][$m]!=$te[$l]->sub[0] && $subjectinclass[$i][$j][$k][$m]!=$te[$l]->sub[1] && $lectures[$l]!=0)
                       {
                           $teacherinclass[$i][$j][$k][$m]=$l;
                           $lectures[$l]--;
                           $l++;
                           $flag=1;
                       }
                       else
                       {
                           $l++;
                       }
                   }while($flag==0);
               }
           }
       }
   }

   echo "<table border =\"1\" style='border-collapse: collapse;width:80%;margin-left:10%;height:50%;text-align: center;'>";
   echo "<tr> \n";
   echo "<th> </td>\n";
   echo "<th colspan='2'>DT 101</td> \n";
   echo "<th colspan='2'>DT 102</td> \n";
   echo "<th colspan='2'>DT 103</td> \n";
   echo "</tr> \n";

   for($i=0;$i<3;$i++)
   {
       $lk=$i+1;
       echo "<tr> ";
       echo "<th >Roster $lk</th> ";

       for($j=0;$j<3;$j++)
       {
           for($k=0;$k<2;$k++)
           {
               echo "<td>";
               for($m=0;$m<2;$m++)
               {
                   $l=$teacherinclass[$i][$j][$k][$m];
                   if($l!=100)
                   {
                       $z=$te[$l]->name;
                       echo " $z,";
                   }
                   else
                   {
                       echo " ";
                   }
               }
           }
       }
       echo "</tr>";
   }
   echo "</table>";
?>
<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<br>
<center><button onclick="window.print()">PRINT</button></center>
</body>
</html>