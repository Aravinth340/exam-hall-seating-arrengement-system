<?php
ob_start();
session_start();

if(!isset($_SESSION['Details'])) {
    header('Location: homepage.php');
    exit;
}
require('seatAllot.php');

// Provide defaults if not set
$seDefaulter = isset($_SESSION['seDefaulter']) ? trim($_SESSION['seDefaulter']) : "0";
$teDefaulter = isset($_SESSION['teDefaulter']) ? trim($_SESSION['teDefaulter']) : "0";
$beDefaulter = isset($_SESSION['beDefaulter']) ? trim($_SESSION['beDefaulter']) : "0";

$se = array();
$seName = array();
$te = array();
$teName = array();
$be = array();
$beName = array();

$conn = mysqli_connect('localhost','root','') or die();
$db = mysqli_select_db($conn,'seatingarrangement');

// Helper function to build SQL based on defaulters
function getStudentSQL($table, $defaulters) {
    if ($defaulters === "0" || $defaulters === "" || preg_replace('/[,\s]/', '', $defaulters) === "") {
        // No defaulters, select all
        return "SELECT `Roll_No`, CONCAT(`first_name`, ' ', `last_name`) FROM `$table`";
    } else {
        return "SELECT `Roll_No`, CONCAT(`first_name`, ' ', `last_name`) FROM `$table` WHERE `Roll_No` NOT IN ($defaulters)";
    }
}

$sqlSE = getStudentSQL('secondyear', $seDefaulter);
$sqlTE = getStudentSQL('thirdyear', $teDefaulter);
$sqlBE = getStudentSQL('fourthyear', $beDefaulter);

$sqlResult1 = mysqli_query($conn, $sqlSE);
$sqlResult2 = mysqli_query($conn, $sqlBE);
$sqlResult3 = mysqli_query($conn, $sqlTE);

if($sqlResult1!=false) {
    while ($row = mysqli_fetch_array($sqlResult1)) {
        $seName[$row[0]]=$row[1];
    }
} else {
    echo "Error in Fetching data for SE";
}

if($sqlResult3!=false) {
    while ($row = mysqli_fetch_array($sqlResult3)) {
        $teName[$row[0]]=$row[1];
    }
} else {
    echo "Error in Fetching data for TE";
}

if($sqlResult2!=false) {
    while ($row = mysqli_fetch_array($sqlResult2)) {
        $beName[$row[0]]=$row[1];
    }
} else {
    echo "Error in Fetching data for BE";
}
mysqli_close($conn);

$seSlots = array_chunk($seName,34);
$teSlots = array_chunk($teName,34);
$beSlots = array_chunk($beName,34);

// Call your PDF generator
seatAllot($seName,$teName,$beName);
?>