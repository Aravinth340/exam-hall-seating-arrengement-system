<?php
ob_start();
for($i = 0; $i < $_SESSION['Details']['noClass']; $i++)
    unset($_SESSION['class_' . $i]);
require_once('fpdf.php');

class pdf extends FPDF
{
    function Header()
    {
        $this->SetMargins(2,2,2);
        $this->Ln();
        $this->SetFont('Times','B',24);
        $this->Cell(0,1,"589,Chendhuran Polytecnic College",0,1,'C');
        $this->SetFont('Times','B',14);
        $this->Cell(0,1,"Department Of Computer Science & Engineering",0,1,'C');
        $this->Cell(0,1,"Seating Arrangement",0,1,'C');
        $this->SetFont('Times','B',12);
        $date = date("d/m/Y");
        $this->Cell(0,1,"Date: $date",0,1,'C');
        $this->Ln();
    }

    function FancyTable($header, $data, $columnWidths)
    {
        $this->SetFont('Times','B',12);
        // Print header row
        for ($i = 0; $i < count($header); $i++) {
            $this->Cell($columnWidths[$i], 1, $header[$i], 1, 0, 'C');
        }
        $this->Ln();

        $this->SetFont('Times','',12);
        // Print data rows
        foreach ($data as $row) {
            $x = $this->GetX();
            $y = $this->GetY();

            // Calculate height of the MultiCell for register numbers
            $register_numbers = $row[2];
            $register_height = $this->NbLines($columnWidths[2], $register_numbers) * 0.8;

            // Set a minimum height (1 cm) for short content
            $cell_height = max(1, $register_height);

            // Print Date and Hall Number cells with correct height
            $this->Cell($columnWidths[0], $cell_height, $row[0], 1, 0, 'C');
            $this->Cell($columnWidths[1], $cell_height, $row[1], 1, 0, 'C');

            // Print Register Numbers with MultiCell
            $xReg = $this->GetX();
            $yReg = $this->GetY();
            $this->MultiCell($columnWidths[2], 0.8, $register_numbers, 1, 'L');
            
            // Move to next row (largest cell height)
            $this->SetXY($x, $y + $cell_height);
        }
    }

    // Helper to estimate number of lines for a multicell
    function NbLines($w, $txt)
    {
        $cw = &$this->CurrentFont['cw'];
        if($w==0)
            $w = $this->w - $this->rMargin - $this->x;
        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if($nb > 0 && $s[$nb-1]=="\n")
            $nb--;
        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $nl = 1;
        while($i < $nb)
        {
            $c = $s[$i];
            if($c == "\n")
            {
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
                continue;
            }
            if($c == ' ')
                $sep = $i;
            $l += $cw[$c];
            if($l > $wmax)
            {
                if($sep == -1)
                {
                    if($i == $j)
                        $i++;
                }
                else
                    $i = $sep + 1;
                $sep = -1;
                $j = $i;
                $l = 0;
                $nl++;
            }
            else
                $i++;
        }
        return $nl;
    }

    function Footer()
    {
        $this->SetY(-3);
        $this->Cell(10,0,"____________________");
        $this->SetX(-(6));
        $this->Cell(0,0,"____________________");
        $this->SetY(-2);
        $this->Cell(4.2,1,"Exam Controller",0,0,'C');
        $this->SetX(-5.8);
        $this->Cell(4,1,"Head Of the Department",0,0,'C');
    }
}

function seatAllot($se, $te, $be)
{
    $date = date("d/m/Y");
    $halls = [
        'SE' => $se,
        'TE' => $te,
        'BE' => $be
    ];

    $header = ['Date', 'Hall Number', 'Register Numbers'];

    // Each hall's register numbers in a single cell, comma-separated
    $data = [];
    foreach ($halls as $hallName => $arr) {
        if (!is_array($arr)) continue;
        // For better readability, break into multiple lines if too many numbers
        $register_numbers = implode(", ", array_keys($arr));
        $data[] = [$date, $hallName, $register_numbers];
    }

    // Decide column widths for landscape A4 (total 29.7cm - 4cm margin = 25.7cm)
    $columnWidths = [4, 4, 17.7];

    $page = new pdf('L','cm','A4'); // Landscape page
    $page->AddPage('L','A4',0);

    $page->FancyTable($header, $data, $columnWidths);

    if (ob_get_length()) {
        ob_end_clean();
    }
    $page->Output('D','SeatingArrangement.pdf');
}